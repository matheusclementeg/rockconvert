=== Rock Content ===
Contributors: rockcontentplatform
Donate link: https://rockcontent.com/
Tags: publication, content marketing
Requires at least: 3.5.0
Tested up to: 4.9.2
Stable tag: 2.4.0

Este fantástico plugin permite integrar o seu blog Wordpress com a plataforma Rock Content.

== Description ==

Instale este plugin em seu blog Wordpress para integrar com a plataforma Rock Content. Este plugin vai permitir Salvar como rascunho, Agendar ou Publicar diretamente pela plataforma os seus conteúdos aprovados.

Principais funções:
- Publicar conteúdos
- Agendar publicação de conteúdos
- Salvar conteúdos como rascunho


== Installation ==

Veja só como é simples:

1. Baixe e instale o plugin diretamente através do diretório de plugins do seu Wordpress
2. Ative o plugin na página de plugins do seu WordPress
3. Após ativado clique no item **Rock Content** na barra lateral do menu do seu Wordpress
4. Na página do plugin clique no botão **Integrar com a plataforma Rock Content**
5. Você será direcionado para confirmar a integração dentro da plataforma **Rock Content**

= O que preciso para usar o plugin? =

* Você precisa ser cliente da Rock Content e ter acesso a plataforma;
* Seu blog precisa ter a extensão OpenSSL habilitada.

== Changelog ==

= 1.0 =
* Início. Let's Rock!

= 1.2.1 =
* Pequenas correções e melhorias

= 1.2.2 =
* Melhorias no upload de imagem

= 2.0.0 =
* Adiciona suporte a Plataforma RC2

= 2.1.0 =
* Adiciona suporte a publicações com tags

= 2.3.0 =
* Adiciona botão de desconectar

= 2.4.0 =
* Adiciona suporte ao Rock Stage

== Upgrade Notice ==

= 1.0 =
* Início. Lets's Rock!
